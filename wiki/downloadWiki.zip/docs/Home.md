VB.NET CMS has been written to fill a hole.

Most CMS systems are huge beasts and modules are difficult to write. Or they're not free. Or they're in another language, which we don't like (-:

VB.NET CMS is:

* Light weight
* Easy to customise
* Written in VB.NET 2005
* Settings stored in MDB database for easy installation
* URL re-writing and search engine optimised
* Templates, Boxes (containers) and Modules easily developed
* Totally customisable, no firm layout styles required

[http://www.vbdotnetcms.com](http://www.vbdotnetcms.com)